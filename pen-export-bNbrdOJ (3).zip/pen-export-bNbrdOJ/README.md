# 席替え１２２６

A Pen created on CodePen.io. Original URL: [https://codepen.io/dzkpdbnv-the-animator/pen/bNbrdOJ](https://codepen.io/dzkpdbnv-the-animator/pen/bNbrdOJ).

